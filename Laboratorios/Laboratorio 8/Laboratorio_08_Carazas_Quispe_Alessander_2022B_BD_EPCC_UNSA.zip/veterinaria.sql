USE veterinaria;

INSERT INTO Consulta_Medicamentos
VALUES (180, 122, 1, 2);

INSERT INTO Consulta_Medicamentos
VALUES (185, 121, 0, 1);

INSERT INTO Consulta_Medicamentos
VALUES (150, 125, 2, 1);

INSERT INTO Consulta_Medicamentos
VALUES (152, 124, 1, 1);

INSERT INTO Consulta_Medicamentos
VALUES (165, 123, 0, 2);

SELECT * FROM Consulta_Medicamentos