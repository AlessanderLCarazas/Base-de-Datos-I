USE cine;


INSERT INTO Horario
VALUES(5, '15:30', '17:00', 05, 12, 2022, 4);

SELECT * FROM Horario;